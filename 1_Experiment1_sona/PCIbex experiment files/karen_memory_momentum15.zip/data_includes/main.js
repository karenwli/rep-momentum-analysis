PennController.ResetPrefix(null) // Shorten command names (keep this line here)

SetCounter("counter", "inc", 1);
   
// Show the 'intro' trial first, then all the 'experiment' trials in a random order
// then send the results and finally show the trial labeled 'bye'
Sequence( "consent", "intro" , randomize("experiment") , "bye" )

//{"introMemory" , randomize("expMemory") , SendResults() ,} [after randomize("experiment")]
newTrial("consent",
    newHtml("consent_form", "consent.html")
        .cssContainer({"width":"700px"})
        .center()
        .checkboxWarning("You must consent before continuing.")
        .print()
    , 
    newButton("continue", "Click here if you consent to participating")
        .center()
        .print()
        .wait(getHtml("consent_form").test.complete()
                  .failure(getHtml("consent_form").warn())
        )
).setOption("hideProgressBar",true)

newTrial( "intro" ,
    newImage("Instructions","Instructions.jpg")
    .size(600,350)
    .print()
    .center()
   ,
    newText("<p style=font-size:18px;>Please enter your PennID below and press Enter:</p>" )
	.print()
    .center()	
        
    ,
    newTextInput("inputID")
        .center()
        .print()
        .wait()                 // The next command won't be executed until Enter is pressed
    ,
    newVar("ID")
        .global()
        .set(getTextInput("inputID"))
    ,
    fullscreen()
).setOption("hideProgressBar",true) 
.log("ID", getVar("ID"))

 
// This Template command generates as many trials as there are rows in myTable.csv
Template( "trials15.csv" ,
    // Row will iteratively point to every row in myTable.csv
    row => newTrial( "experiment" ,
       newImage("fixation", "fixation.png")
            .size("90%", "90%")
        ,
        newCanvas("canvas1", 350, 262.5)
            .center()
            .add("center",65, getImage("fixation") )
            .print()
        ,
        newTimer("timer1", 500)
            .start()
            .wait()
        ,
        clear()
        , 
        newText("goal", "<p style=font-size:18px;>" + row.goal + "</p>")
        .center()
        ,
        newImage("picture", "https://raw.githubusercontent.com/karenwli/rep-momentum/main/" + row.item + "/" + row.item + "00.jpg")
        ,
        newCanvas("canvas2", 350, 262.5)
            .center()
            .add("center", 0, getText("goal"))
            .add("center", 65 , getImage("picture") )
            .print()
        , 
        newTimer("wait", 3500)
            .start()
            .wait()
        ,
        clear()
        ,
        newVideo("progression", "https:" + row.video_link)
            .disable(0.01) 
            .print()
            .once()
            .play()
        ,
        newCanvas("canvas3", 350, 262.5)
            .center()
            .add("center", 65 , getVideo("progression") )
            .print()
        ,
        getVideo("progression")
            .wait()
        ,
        clear()
        ,
        newImage("mask", row.mask_link)
            .size("90%", "90%")
        ,
        newCanvas("canvas5", 350, 262.5) 
            .center()
            .add("center at 50%", 65, getImage("mask") )
            .print()
        ,
        newTimer("timer4", 1000)
            .start()
            .wait()
        ,
        clear() 
        ,
        newImage("option1", "https://raw.githubusercontent.com/karenwli/rep-momentum/main/" + row.item + "/" + row.prev_image)
        ,
        newImage("option2", "https://raw.githubusercontent.com/karenwli/rep-momentum/main/" + row.item + "/" + row.next_image)
        ,
        newText("question", "<p style=font-size:18px;>"+ "Choose the last frame you saw before the video disappeared"+ "</p>")
        ,
        newCanvas("canvas6", 750, 400)
            .add("center at 50%", "top at 0%", getText("question"))
            .add(0, 100, getImage("option1"))
            .add(450, 100, getImage("option2"))
            .center()
            .print()
            .log()
        ,
        newSelector("choice")
            .add(getImage("option1"), getImage("option2"))
            .shuffle()
            .wait()
            .log() 
        ).setOption("hideProgressBar",true)
        .log("ID", getVar("ID"))
        .log("item_number", row.item_number)
        .log("item", row.item)
        .log("type", row.type)
        .log("Group", row.Group)
        .log("prog", row.prog)
        .log("prev_image", row.prev_image)
        .log("next_image", row.next_image)
        .log("height", row.height)
        )

    
/*newTrial( "introMemory" ,
    newText("<p style=font-size:18px;>You have finished the first part of the experiment.</p>" +
            "<p style=font-size:18px;>In the next section, your memory for the images you just saw will be tested.</p>" +
            "<p style=font-size:18px;>You will see an image and will be asked whether you saw it in the first part of the experiment.<p style=font-size:18px;>" +
            "<p style=font-size:18px;>To answer each question, press <strong>d</strong> for yes and <strong>k</strong> for no.</p><p style=font-size:18px;>" +		
			"<p style=font-size:18px;>Press <strong>Enter</strong> to continue.</p>")
		.center()
        .print()
).setOption("hideProgressBar",true)
.log("ID", getVar("ID"))

// This Template command generates as many trials as there are rows in memory.csv
Template( "memory.csv" ,
    // Row will iteratively point to every row in memory.csv
    row => newTrial( "expMemory" ,

        newImage("picture", "https:" + row.Picture)
            .size(350, 262.5)
        ,
        newCanvas("canvas", 350, 262.5)
            .center()
            .add( "center at 50%" , "center at 50%" , getImage("picture") )
            .print()
        ,
        newTimer("wait", 500)
            .start()
            .wait()
       
        ,
        newText("<p style=font-size:18px;>Did you see this image earlier?</p>")
            .log()
            .center()
            .print()
        ,        
        newCanvas("canvas2", 400, 20)
            .add(40, 0, newText("<p style=font-size:18px;>Yes</p>"))
            .add(340, 0, newText("<p style=font-size:18px;>No</p>"))
            .print()
        ,
		newText(row.Verb)
     .log()
,
        newKey("answer", "DK")
            .log()
            .wait()
        ).setOption("hideProgressBar",true)
        .log("ID", getVar("ID"))
)*/

// Spaces and linebreaks don't matter to the script: we've only been using them for the sake of readability
newTrial( "bye" ,
    newText("<p style=font-size:18px;>Thank you for your participation!</p>").print(),
    newButton().wait()  // Wait for a click on a non-displayed button = wait here forever
).setOption("hideProgressBar",true)
//PennController.DebugOff()
.setOption( "countsForProgressBar" , false )
// Make sure the progress bar is full upon reaching this last (non-)trial